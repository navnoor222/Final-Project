# Discord Hangman Bot

![Screenshot 4](Assets\Images\Bot.jpeg)



## Overview
This Discord bot is designed to facilitate a game of Hangman within Discord servers. Users can start a new game, guess letters, receive hints, and view the current game status. The bot also integrates with an external data source to provide hints based on capital city information retrieved from the HackerRank API.

## Features
1. **Start Command**: Initiates a new game of Hangman.
2. **Guess Command**: Allows users to guess letters in the word during a game.
3. **Hint Command**: Provides a hint for the current game by retrieving capital city information from the HackerRank API.
4. **Help Command**: Displays a list of available commands and their descriptions.
5. **Database Integration**: Stores user IDs in a MySQL database to track player participation.

## Commands
- `!start`: Start a new game of Hangman.
- `!guess <letter>`: Guess a letter in the word.
- `!hint`: Get a hint for the current game.
- `!help`: Display a list of available commands.

## External Data Source
The bot integrates with the HackerRank API to retrieve capital city information for hints during the Hangman game. This API is queried based on the selected word from a predefined word list.

## Implementation Details
- **Programming Language**: Python
- **Discord API Library**: discord.py
- **External Libraries**: mysql-connector-python, requests
- **Deployment**: The bot is deployed using a Discord bot token generated from the Discord Developer Portal.

## Setup Instructions
1. Clone the repository containing the bot code.
2. Install the required Python libraries using pip.
3. Set up a MySQL database and configure the connection details in the bot code.
4. Obtain a Discord bot token from the Discord Developer Portal.
5. Update the settings file with the Discord bot token and other configuration details.
6. Run the bot script using Python.

## Working 

![Screenshot 1](Assets\Images\Working1.png)
![Screenshot 2](Assets\Images\Working2.png)
![Screenshot 3](Assets\Images\Working3.png)
![Screenshot 5](Assets\Images\sql.png)



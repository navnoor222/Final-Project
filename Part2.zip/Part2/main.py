import settings
import random
import requests
import mysql.connector
from discord.ext import commands
import discord

BOT_TOKEN = settings.DISCORD_API_TOKEN
MAX_SESSION_TIME_MINUTES = 45

class HangmanSession:
    def __init__(self):
        self.is_active = False
        self.word = ""
        self.guessed_letters = set()
        self.max_attempts = 6
        self.hint = ""

bot = commands.Bot(command_prefix="!", intents=discord.Intents.all())
session = HangmanSession()
bot.remove_command("help")

# Connect to MySQL database
db = mysql.connector.connect(
    host="localhost",
    user=settings.DB_USER,
    password=settings.DB_PASS,
    database="hangman_bot"
)
cursor = db.cursor()

@bot.event
async def on_ready():
    print("Hangman bot is ready!")
    await bot.change_presence(activity=discord.Game(name="Hangman"))
    for guild in bot.guilds:
        default_channel = guild.text_channels[0]  
        await default_channel.send("Hangman bot is now active!")

def load_word_list():
    with open("countries.txt", "r", encoding="utf-8") as file:
        return [line.strip() for line in file]

def getCapitalCity(country):
    api_request = requests.get('https://jsonmock.hackerrank.com/api/countries?name='+country)
    data = api_request.json()['data']
    if len(data) == 0 or 'capital' not in data[0]:
        return None
    return data[0]['capital']

@bot.command()
async def start(ctx):
    if session.is_active:
        await ctx.send("A game is already active!")
        return

    session.is_active = True
    word_list = load_word_list()
    session.word = random.choice(word_list)
    session.guessed_letters = set()
    session.attempts = 0
    session.hint = ""
    
    user_id = ctx.author.id
    try:
        cursor.execute("INSERT IGNORE INTO user_ids (discord_id) VALUES (%s)", (user_id,))
        db.commit()
    except mysql.connector.Error as err:
        print(f"Error adding user ID to database: {err}")

    await ctx.send("🎮 Hangman game started! Use `!guess <letter>` to guess a letter.")
    await display_status(ctx)

async def display_status(ctx):
    word_display = ''.join(char if char in session.guessed_letters else '_' for char in session.word)
    attempts_left = session.max_attempts - session.attempts
    hint_message = f"\n🔍 Hint: {session.hint}" if session.hint else ""
    word_length_message = f"\nTotal characters in the word: {len(session.word)}"
    await ctx.send(f"Current status: {word_display}\nAttempts left: {attempts_left}{hint_message}{word_length_message}")

@bot.command()
async def guess(ctx, letter):
    if not session.is_active:
        await ctx.send("❌ No game is active. Start a new game using `!start`.")
        return

    if letter in session.guessed_letters:
        await ctx.send("❌ You've already guessed that letter!")
        return

    session.guessed_letters.add(letter)
    if letter not in session.word:
        session.attempts += 1

    if all(letter in session.guessed_letters for letter in session.word):
        await ctx.send(f"🎉 Congratulations! You guessed the word: {session.word}")
        session.is_active = False
    elif session.attempts >= session.max_attempts:
        await ctx.send(f"💀 Game over! The word was: {session.word}")
        session.is_active = False
    else:
        await display_status(ctx)

@bot.command()
async def hint(ctx):
    if not session.is_active:
        await ctx.send("❌ No game is active. Start a new game using `!start`.")
        return

    if not session.hint:
        session.hint = getCapitalCity(session.word)
        if not session.hint:
            session.hint = "❓ No capital city information available."

    await ctx.send(f"🔍 Hint: {session.hint}")

@bot.command()
async def help(ctx):
    help_message = """
    **Hangman Bot Commands:**
    `!start` - Start a new game of Hangman.
    `!guess <letter>` - Guess a letter in the word.
    `!hint` - Get a hint for the current game.
    """
    await ctx.send(help_message)

@bot.command()
async def add_id(ctx):
    user_id = ctx.author.id
    try:
        cursor.execute("INSERT INTO user_ids (discord_id) VALUES (%s)", (user_id,))
        db.commit()
        await ctx.send("✅ Your user ID has been added to the database.")
    except mysql.connector.Error as err:
        await ctx.send(f"❌ Error: {err}")

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound):
        await ctx.send("❌ This command does not exist. Type `!help` for a list of available commands.")

bot.run(BOT_TOKEN)

DROP DATABASE IF EXISTS hangman_bot;

CREATE DATABASE hangman_bot;

USE hangman_bot;

DROP TABLE IF EXISTS user_ids;

CREATE TABLE user_ids (
    id INT AUTO_INCREMENT PRIMARY KEY,
    discord_id VARCHAR(255) UNIQUE NOT NULL
);


select *from user_ids;
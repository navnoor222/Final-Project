import os
from dotenv import load_dotenv
load_dotenv()

DISCORD_API_TOKEN=os.getenv('DISCORD_API_TOKEN')
CHANNEL_ID=os.getenv('CHANNEL_ID')
GPT_API=os.getenv('GPT_API')
DB_USER=os.getenv('DB_USER')
DB_PASS=os.getenv('DB_PASS')
DB_DB=os.getenv('hangman_bot')

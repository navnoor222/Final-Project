# Analysis Report

## Introduction
This report presents an analysis of data fetched from an API and stored in the `apiData` table in the `amazonApi` database. The analysis aims to explore the relationship between the data fields (`factor` and `pi`) and their changes over time. Additionally, it includes a description of the API used, the login process, and the database used for storage.

## API Description
The API used for data retrieval is hosted at `https://4feaquhyai.execute-api.us-east-1.amazonaws.com/api/pi`. This API provides real-time data consisting of three fields: `factor`, `pi`, and `time`. The `factor` field represents a numerical factor, `pi` represents a decimal value, and `time` indicates the timestamp when the data was generated.

## Login Process
The login process involves accessing the API endpoint with appropriate credentials or authorization tokens. In this case, no specific login process is mentioned in the provided Python script. Therefore, it is assumed that the API is publicly accessible without any authentication requirements.

## Database Description
The data fetched from the API is stored in the `apiData` table within the `amazonApi` database. The `apiData` table has columns for `factor`, `pi`, and `time`, allowing for the storage of real-time data collected from the API.
![Screenshot 1](Images\database.png)


## Data Overview
The dataset fetched from the API and stored in the `apiData` table contains records of `factor`, `pi`, and `time` columns. The `factor` represents a numerical factor, while `pi` represents a decimal value. Time indicates the timestamp when the data was collected.

## Time Series Analysis
The time series analysis reveals trends in the `factor` and `pi` values over time. The plot indicates fluctuations in both `factor` and `pi` values but does not exhibit any clear patterns or trends.

![Screenshot 2](Images\analysis.png)


## Statistical Analysis
- **Factor Mean**: 50890.97
- **Pi Mean**: 3.1686
- **Factor Standard Deviation**: 60401.84
- **Pi Standard Deviation**: 0.1566
- **Correlation between Factor and Pi**: -0.1454

The statistical analysis indicates that the `factor` values have a high mean and standard deviation, suggesting significant variability in the data. However, the correlation between `factor` and `pi` is negative, indicating a weak inverse relationship between the two variables.

## Anomaly Detection
No outliers were detected in the `factor` values. However, outliers were observed in the `pi` values at timestamps 18:00:16 and 18:01:17.

![Screenshot 3](Images\outlier.png)


## Conclusion
The analysis suggests that the `factor` and `pi` values exhibit variability over time, but no significant patterns or trends were observed. Further analysis may be required to understand the underlying factors contributing to the fluctuations in the data.


DROP DATABASE IF EXISTS amazonApi;
CREATE DATABASE amazonApi;
USE amazonApi;

DROP TABLE IF EXISTS apiData;

CREATE TABLE apiData (
    id INT AUTO_INCREMENT PRIMARY KEY,
    factor INT,
    pi DECIMAL(5, 3),
    time DATETIME
);




	